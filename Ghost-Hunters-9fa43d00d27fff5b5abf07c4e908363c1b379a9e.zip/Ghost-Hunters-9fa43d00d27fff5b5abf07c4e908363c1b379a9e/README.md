# Ghost-Hunters
Ghost Hunters was a game that I made using Pygame with original assets made by me. This project was made as a final culminating task for my ICS3U course which I achieved a 99% in.

![](https://github.com/ColeBranston/Ghost-Hunters/blob/main/readmeGIF.gif)
![](https://github.com/ColeBranston/Ghost-Hunters/blob/main/readmeGIF2%20(2).gif)
